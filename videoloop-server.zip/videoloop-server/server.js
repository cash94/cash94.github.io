const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const https = require('https');
const http = require('http');

const app = express();
const PORT = process.env.PORT || 3000;
const CACHE_DIR = path.join(__dirname, 'cache');
const HLS_DIR = path.join(__dirname, 'hls');

if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR);
if (!fs.existsSync(HLS_DIR)) fs.mkdirSync(HLS_DIR);

// Очередь операций для каждого streamId
const operationQueue = new Map();

// Функция для последовательного выполнения операций над потоком
async function queueOperation(streamId, operation) {
  if (!operationQueue.has(streamId)) {
    operationQueue.set(streamId, Promise.resolve());
  }
  
  const queue = operationQueue.get(streamId);
  const result = queue.then(() => operation()).catch(err => {
    console.error(`[${streamId}] Ошибка в очереди:`, err);
    return Promise.reject(err);
  });
  
  operationQueue.set(streamId, result.catch(() => {}));
  return result;
}

function cleanupStreamDir(streamId, outputDir) {
  return new Promise((resolve) => {
    console.log(`[${streamId}] Очистка директории: ${outputDir}`);
    if (fs.existsSync(outputDir)) {
      fs.rm(outputDir, { recursive: true, force: true }, (err) => {
        if (err) console.error(`[${streamId}] Ошибка удаления:`, err);
        else console.log(`[${streamId}] Директория удалена`);
        resolve();
      });
    } else {
      resolve();
    }
  });
}

// Функция для гарантированного завершения процесса FFmpeg
function killFfmpegProcess(process, streamId) {
  return new Promise((resolve) => {
    if (!process || process.killed) {
      resolve();
      return;
    }
    
    console.log(`[${streamId}] Завершение процесса FFmpeg...`);
    
    let forceKillTimeout = setTimeout(() => {
      if (!process.killed) {
        console.log(`[${streamId}] Принудительное завершение FFmpeg (SIGKILL)`);
        process.kill('SIGKILL');
      }
    }, 3000);
    
    process.once('exit', () => {
      clearTimeout(forceKillTimeout);
      console.log(`[${streamId}] Процесс FFmpeg завершен`);
      resolve();
    });
    
    process.once('error', () => {
      clearTimeout(forceKillTimeout);
      resolve();
    });
    
    process.kill('SIGTERM');
  });
}

// Очистка старых потоков
setInterval(() => {
  const now = Date.now();
  fs.readdir(HLS_DIR, (err, files) => {
    if (err) return;
    files.forEach(file => {
      const filePath = path.join(HLS_DIR, file);
      fs.stat(filePath, (err, stats) => {
        if (err) return;
        if (now - stats.mtimeMs > 3600000) {
          fs.rm(filePath, { recursive: true, force: true }, () => {});
        }
      });
    });
  });
}, 3600000);

app.use(cors({ origin: ['http://localhost:3000', 'http://127.0.0.1:3000', '*'], credentials: true }));
app.use(express.json());
app.use(express.static('public'));
app.use('/hls', express.static(HLS_DIR));

const activeStreams = new Map();

function checkFfmpeg() {
  return new Promise((resolve) => {
    const ffmpeg = spawn('ffmpeg', ['-version']);
    ffmpeg.on('error', () => resolve(false));
    ffmpeg.on('exit', (code) => resolve(code === 0));
  });
}

function getVideoDuration(inputUrl) {
  return new Promise((resolve) => {
    const ffprobe = spawn('ffprobe', ['-v', 'quiet', '-print_format', 'json', '-show_format', '-i', inputUrl]);
    let output = '';
    ffprobe.stdout.on('data', data => output += data);
    ffprobe.on('close', (code) => {
      if (code === 0 && output) {
        try {
          const info = JSON.parse(output);
          const duration = parseFloat(info.format?.duration);
          resolve(isFinite(duration) && duration > 0 ? duration : null);
        } catch { resolve(null); }
      } else { resolve(null); }
    });
    ffprobe.on('error', () => resolve(null));
    setTimeout(() => { ffprobe.kill('SIGKILL'); resolve(null); }, 10000);
  });
}

function detectVideoCodec(inputUrl) {
  return new Promise((resolve) => {
    const ffprobe = spawn('ffprobe', ['-v', 'quiet', '-print_format', 'json', '-show_streams', '-select_streams', 'v:0', inputUrl]);
    let output = '';
    ffprobe.stdout.on('data', data => output += data.toString());
    ffprobe.on('close', (code) => {
      if (code === 0 && output) {
        try {
          const info = JSON.parse(output);
          const stream = info.streams[0];
          resolve({ codec: stream.codec_name, tag: stream.codec_tag_string, width: stream.width, height: stream.height, bitrate: stream.bit_rate });
        } catch { resolve({ codec: 'h264' }); }
      } else { resolve({ codec: 'h264' }); }
    });
  });
}

// Функция создания HLS потока с таймаутом
async function createHLSStream(inputUrl, streamId, startTime = null) {
  const outputDir = path.join(HLS_DIR, streamId);
  const playlistPath = path.join(outputDir, 'playlist.m3u8');
  const initPath = path.join(outputDir, 'init.mp4');
  const segmentPath = path.join(outputDir, 'segment%d.mp4');
  
  // Создаем директорию
  if (fs.existsSync(outputDir)) {
    await cleanupStreamDir(streamId, outputDir);
  }
  fs.mkdirSync(outputDir, { recursive: true });
  
  const seekInfo = startTime ? ` (начало с ${startTime.toFixed(2)}s)` : '';
  console.log(`[${streamId}] Создание HLS потока для: ${inputUrl}${seekInfo}`);
  
  // Получаем информацию о видео с таймаутом
  const videoInfoPromise = detectVideoCodec(inputUrl).catch(() => ({ codec: 'h264' }));
  const durationPromise = getVideoDuration(inputUrl);
  
  const [videoInfo, duration] = await Promise.all([
    videoInfoPromise,
    durationPromise
  ]);
  
  const adjustedDuration = (duration && startTime) ? Math.max(0, duration - startTime) : duration;
  console.log(`[${streamId}] Длительность: ${adjustedDuration ? adjustedDuration.toFixed(2) + 's' : 'неизвестна'}`);

  let bsf = '', vtag = '';
  switch (videoInfo.codec) {
    case 'hevc': case 'h265': case 'hevc_cuvid': bsf = 'hevc_mp4toannexb'; vtag = 'hvc1'; break;
    case 'av1': bsf = 'av1_mp4toannexb'; vtag = 'av01'; break;
    case 'vp9': bsf = 'vp9_superframe'; vtag = 'vp09'; break;
    case 'h264': case 'h264_cuvid': default: bsf = 'h264_mp4toannexb'; vtag = 'avc1'; break;
  }

  // Формируем аргументы FFmpeg
  const ffmpegArgs = [];
  
  if (startTime && startTime > 0) {
    ffmpegArgs.push('-ss', startTime.toFixed(3));
  }
  
  ffmpegArgs.push(
    '-analyzeduration', '200M', 
    '-probesize', '1G', 
    '-readrate', '10', 
    '-fflags', '+genpts',
    '-i', inputUrl
  );
  
  if (startTime && startTime > 0) {
    ffmpegArgs.push('-ss', startTime.toFixed(3));
  }
  
  ffmpegArgs.push(
    '-map_metadata', '-1', 
    '-map_chapters', '-1',
    '-threads', '0', 
    '-map', '0:v:0', 
    '-map', '0:a:0', 
    '-map', '-0:s',
    '-codec:v:0', 'copy', 
    '-tag:v:0', vtag, 
    '-bsf:v', bsf,
    '-codec:a:0', 'aac', 
    '-ac', '2', 
    '-ab', '256000',
    '-start_at_zero', 
    '-copyts', 
    '-avoid_negative_ts', 'disabled',
    '-max_muxing_queue_size', '2048',
    '-f', 'hls', 
    '-max_delay', '5000000',
    '-hls_time', '6', 
    '-hls_segment_type', 'fmp4',
    '-hls_fmp4_init_filename', 'init.mp4',
    '-start_number', '0', 
    '-hls_segment_filename', segmentPath,
    '-hls_playlist_type', 'event', 
    '-hls_list_size', '0',
    '-hls_segment_options', 'movflags=+frag_discont',
    '-y', playlistPath
  );

  console.log(`[${streamId}] FFmpeg args:`, ffmpegArgs.join(' '));

  return new Promise((resolve, reject) => {
    const ffmpeg = spawn('ffmpeg', ffmpegArgs, { cwd: outputDir });
    
    let ffmpegError = '';
    let playlistCreated = false;
    let processExited = false;
    
    const processTimeout = setTimeout(() => {
      if (!playlistCreated && !processExited) {
        console.error(`[${streamId}] Таймаут создания потока`);
        ffmpeg.kill('SIGKILL');
        reject(new Error('Timeout creating HLS stream'));
      }
    }, 30000);
    
    ffmpeg.stderr.on('data', data => {
      const output = data.toString();
      ffmpegError += output;
      
      if (output.includes('Error') || output.includes('error')) {
        console.error(`[${streamId}] FFmpeg ошибка:`, output);
      }
      
      // Проверяем создание первого сегмента
      if (!playlistCreated && fs.existsSync(playlistPath)) {
        playlistCreated = true;
        clearTimeout(processTimeout);
        
        console.log(`[${streamId}] Плейлист создан, продолжаем в фоне`);
        
        const streamInfo = {
          id: streamId, 
          process: ffmpeg, 
          url: inputUrl, 
          outputDir, 
          playlistPath, 
          initPath,
          startTime: Date.now(), 
          clients: new Set(), 
          videoInfo, 
          duration: adjustedDuration, 
          originalDuration: duration,
          seekOffset: startTime || 0,
          timeout: null
        };
        
        activeStreams.set(streamId, streamInfo);
        
        resolve({
          success: true, 
          streamId, 
          playlistUrl: `/hls/${streamId}/playlist.m3u8`,
          type: 'hls', 
          videoInfo, 
          duration: adjustedDuration, 
          originalDuration: duration, 
          seekOffset: startTime || 0
        });
      }
    });
    
    ffmpeg.on('close', (code) => {
      processExited = true;
      clearTimeout(processTimeout);
      
      console.log(`[${streamId}] FFmpeg завершился с кодом ${code}`);
      
      const currentStream = activeStreams.get(streamId);
      if (currentStream && currentStream.process === ffmpeg) {
        activeStreams.delete(streamId);
      }
      
      if (!playlistCreated) {
        reject(new Error(`FFmpeg exited with code ${code}: ${ffmpegError}`));
      }
    });
    
    ffmpeg.on('error', (err) => {
      processExited = true;
      clearTimeout(processTimeout);
      
      console.error(`[${streamId}] FFmpeg процесс ошибка:`, err);
      
      const currentStream = activeStreams.get(streamId);
      if (currentStream && currentStream.process === ffmpeg) {
        activeStreams.delete(streamId);
      }
      
      if (!playlistCreated) {
        reject(err);
      }
    });
  });
}

// Эндпоинт создания потока
app.get('/hls/stream', async (req, res) => {
  const videoUrl = req.query.url;
  const seekParam = req.query.start || req.query.seek || req.query.t;
  
  if (!videoUrl) return res.status(400).json({ error: 'URL не указан' });
  const decodedUrl = decodeURIComponent(videoUrl);
  
  try { new URL(decodedUrl); } catch (e) { return res.status(400).json({ error: 'Некорректный URL' }); }
  
  const ffmpegAvailable = await checkFfmpeg();
  if (!ffmpegAvailable) return res.status(500).json({ error: 'FFmpeg не установлен' });
  
  let startTime = null;
  if (seekParam) {
    const parsed = parseFloat(seekParam);
    if (isFinite(parsed) && parsed >= 0) {
      startTime = parsed;
      console.log(`🔍 Seek запрошен: ${startTime.toFixed(2)}s`);
    }
  }
  
  const streamId = crypto.randomBytes(16).toString('hex');
  
  try {
    const result = await createHLSStream(decodedUrl, streamId, startTime);
    res.json(result);
  } catch (error) {
    console.error('Ошибка создания потока:', error);
    res.status(500).json({ error: error.message });
  }
});

// ИСПРАВЛЕННЫЙ эндпоинт перемотки с очередью операций
app.post('/hls/stream/seek', async (req, res) => {
  const { streamId, seekTime } = req.body;
  
  if (!streamId || seekTime === undefined || seekTime === null) {
    return res.status(400).json({ error: 'Требуется streamId и seekTime' });
  }
  
  console.log(`[SEEK] Запрос перемотки для ${streamId} на ${seekTime.toFixed(2)}s`);
  
  // Используем очередь для последовательного выполнения операций над этим потоком
  await queueOperation(streamId, async () => {
    // Получаем старый поток
    const oldStream = activeStreams.get(streamId);
    if (!oldStream) {
      throw new Error('Поток не найден');
    }
    
    const videoUrl = oldStream.url;
    const clients = new Set(oldStream.clients);
    
    console.log(`[SEEK] Текущих клиентов: ${clients.size}`);
    
    // 1. Останавливаем старый процесс
    if (oldStream.process && !oldStream.process.killed) {
      await killFfmpegProcess(oldStream.process, streamId);
    }
    
    // 2. Удаляем старую запись
    activeStreams.delete(streamId);
    
    // 3. Очищаем старую директорию (не ждем)
    cleanupStreamDir(streamId, oldStream.outputDir).catch(err => {
      console.error(`[${streamId}] Ошибка очистки:`, err);
    });
    
    // 4. Создаем новый поток с тем же streamId
    try {
      console.log(`[SEEK] Создание нового потока ${streamId} с seek на ${seekTime.toFixed(2)}s`);
      
      const result = await createHLSStream(videoUrl, streamId, seekTime);
      
      // 5. Переносим клиентов
      const newStream = activeStreams.get(streamId);
      if (newStream) {
        clients.forEach(client => newStream.clients.add(client));
        console.log(`[SEEK] Перенесено ${newStream.clients.size} клиентов`);
      }
      
      // 6. Отправляем ответ
      res.json({
        success: true,
        streamId: streamId,
        playlistUrl: `/hls/${streamId}/playlist.m3u8`,
        duration: result.duration,
        originalDuration: result.originalDuration,
        seekOffset: seekTime
      });
      
    } catch (error) {
      console.error('[SEEK] Ошибка создания нового потока:', error);
      throw error;
    }
  }).catch(error => {
    console.error('[SEEK] Ошибка в очереди:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Ошибка перемотки: ' + error.message });
    }
  });
});

app.get('/hls/:streamId/:file', (req, res) => {
  const { streamId, file } = req.params;
  const filePath = path.join(HLS_DIR, streamId, file);
  
  if (!filePath.startsWith(HLS_DIR)) {
    return res.status(403).json({ error: 'Доступ запрещен' });
  }
  
  // Проверяем существование файла
  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (err) {
      console.log(`[${streamId}] Файл не найден: ${file}`);
      return res.status(404).json({ error: 'Файл не найден' });
    }
    
    const stream = activeStreams.get(streamId);
    
    if (stream && file.endsWith('.m3u8')) {
      const clientId = `${req.ip}:${req.headers['user-agent'] || 'unknown'}`;
      
      if (!stream.clients.has(clientId)) {
        console.log(`[${streamId}] Новый клиент: ${clientId}`);
        stream.clients.add(clientId);
        
        if (stream.timeout) {
          clearTimeout(stream.timeout);
          stream.timeout = null;
        }
      }
      
      req.on('close', () => {
        setTimeout(() => {
          if (stream && stream.clients.has(clientId)) {
            setTimeout(() => {
              if (stream && stream.clients.has(clientId)) {
                stream.clients.delete(clientId);
                console.log(`[${streamId}] Клиент отключился: ${clientId}, осталось: ${stream.clients.size}`);
                
                if (stream.clients.size === 0) {
                  console.log(`[${streamId}] Нет клиентов, остановка через 5с`);
                  if (stream.timeout) clearTimeout(stream.timeout);
                  stream.timeout = setTimeout(() => {
                    const currentStream = activeStreams.get(streamId);
                    if (currentStream && currentStream.clients.size === 0) {
                      console.log(`[${streamId}] Останавливаем FFmpeg`);
                      if (currentStream.process && !currentStream.process.killed) {
                        currentStream.process.kill('SIGTERM');
                      }
                      activeStreams.delete(streamId);
                      cleanupStreamDir(streamId, currentStream.outputDir);
                    }
                  }, 5000);
                }
              }
            }, 2000);
          }
        }, 1000);
      });
    }
    
    // Устанавливаем заголовки
    if (file.endsWith('.m3u8')) {
      res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    } else if (file.endsWith('.mp4')) {
      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Cache-Control', 'public, max-age=60');
    }
    
    res.sendFile(filePath);
  });
});

app.get('/hls/status/:streamId', (req, res) => {
  const stream = activeStreams.get(req.params.streamId);
  if (stream) {
    let files = [];
    try {
      files = fs.existsSync(stream.outputDir) ? fs.readdirSync(stream.outputDir) : [];
    } catch (e) {
      console.error(`[${stream.id}] Ошибка чтения директории:`, e);
    }
    
    res.json({
      id: stream.id, 
      url: stream.url, 
      uptime: Date.now() - stream.startTime,
      clients: stream.clients.size, 
      clientsList: Array.from(stream.clients),
      videoInfo: stream.videoInfo, 
      duration: stream.duration, 
      originalDuration: stream.originalDuration,
      seekOffset: stream.seekOffset, 
      filesCount: files.length,
      initExists: fs.existsSync(stream.initPath), 
      playlistExists: fs.existsSync(stream.playlistPath),
      ffmpegRunning: stream.process && !stream.process.killed
    });
  } else { 
    res.status(404).json({ error: 'Поток не найден' }); 
  }
});

app.post('/hls/stop/:streamId', async (req, res) => {
  const stream = activeStreams.get(req.params.streamId);
  if (stream) {
    if (stream.timeout) clearTimeout(stream.timeout);
    
    if (stream.process && !stream.process.killed) {
      await killFfmpegProcess(stream.process, stream.id);
    }
    
    activeStreams.delete(req.params.streamId);
    await cleanupStreamDir(req.params.streamId, stream.outputDir);
    
    res.json({ success: true });
  } else { 
    res.status(404).json({ error: 'Поток не найден' }); 
  }
});

app.get('/video-info', async (req, res) => {
  const videoUrl = req.query.url;
  if (!videoUrl) return res.status(400).json({ error: 'URL не указан' });
  const decodedUrl = decodeURIComponent(videoUrl);
  try {
    const [info, duration] = await Promise.all([
      detectVideoCodec(decodedUrl).catch(() => ({ codec: 'unknown' })),
      getVideoDuration(decodedUrl)
    ]);
    res.json({ ...info, duration });
  } catch (error) { 
    res.status(500).json({ error: error.message }); 
  }
});

app.get('/status', async (req, res) => {
  const ffmpegAvailable = await checkFfmpeg();
  const streams = Array.from(activeStreams.entries()).map(([id, s]) => ({
    id, 
    clients: s.clients.size, 
    uptime: Date.now() - s.startTime,
    url: s.url.substring(0, 50) + (s.url.length > 50 ? '...' : ''), 
    duration: s.duration, 
    originalDuration: s.originalDuration, 
    seekOffset: s.seekOffset,
    ffmpegRunning: s.process && !s.process.killed
  }));
  
  res.json({
    status: 'running', 
    streamsCount: activeStreams.size, 
    ffmpeg: ffmpegAvailable ? 'available' : 'not found',
    streams
  });
});

async function startServer() {
  console.log('🔍 Проверка FFmpeg...');
  const ffmpegAvailable = await checkFfmpeg();
  if (!ffmpegAvailable) {
    console.log('\n⚠️  FFmpeg не найден!');
    console.log('Установите FFmpeg и добавьте в PATH\n');
  } else {
    console.log('✅ FFmpeg найден');
  }
  
  app.listen(PORT, () => {
    console.log(`\n🚀 Сервер запущен на порту ${PORT}`);
    console.log(`🌐 http://localhost:${PORT}`);
    console.log(`📹 HLS: http://localhost:${PORT}/hls/stream?url=ВАШ_URL[&start=123.45]`);
  });
}

startServer();